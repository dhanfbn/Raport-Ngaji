"use client";

import { useEffect, useState, useCallback } from "react";
import type { DashboardData, ReportPeriod } from "@/types";
import Dashboard from "@/components/Dashboard";
import LoginPage from "@/components/LoginPage";

// Shape of the logged-in student stored in sessionStorage
interface AuthStudent {
  student_id: string;
  full_name: string;
  class_id: string;
  gender: string;
}

const SESSION_KEY = "ngaji_sore_auth";

export default function Home() {
  const [auth, setAuth] = useState<AuthStudent | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  // Restore session from sessionStorage on mount
  useEffect(() => {
    try {
      const saved = sessionStorage.getItem(SESSION_KEY);
      if (saved) setAuth(JSON.parse(saved));
    } catch {
      // ignore
    }
    setAuthChecked(true);
  }, []);

  function handleLogin(student: AuthStudent) {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(student));
    setAuth(student);
  }

  function handleLogout() {
    sessionStorage.removeItem(SESSION_KEY);
    setAuth(null);
  }

  // Don't render anything until we've checked sessionStorage
  if (!authChecked) return null;

  if (!auth) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <DashboardShell
      studentId={auth.student_id}
      studentName={auth.full_name}
      onLogout={handleLogout}
    />
  );
}

// ─── Dashboard shell (only mounts after login) ────────────────────────────────

interface ShellProps {
  studentId: string;
  studentName: string;
  onLogout: () => void;
}

const NAV_ITEMS = [
  { icon: "🏠", label: "Ringkasan" },
  { icon: "📅", label: "Kehadiran" },
  { icon: "📖", label: "Tilawah" },
  { icon: "⭐", label: "Hafalan" },
  { icon: "💛", label: "Adab & Sikap" },
  { icon: "📋", label: "Catatan Guru" },
];

function DashboardShell({ studentId, studentName, onLogout }: ShellProps) {
  const [periods, setPeriods] = useState<ReportPeriod[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<string>("");
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeNav, setActiveNav] = useState("Ringkasan");

  // Load period list once
  useEffect(() => {
    async function loadPeriods() {
      try {
        const res = await fetch("/api/dashboard?studentId=list");
        const json = await res.json();
        if (!res.ok) throw new Error(json.error ?? `HTTP ${res.status}`);

        const allPeriods: ReportPeriod[] = json.periods ?? [];
        setPeriods(allPeriods);

        const active = allPeriods.find((p) => p.status?.toLowerCase() === "active");
        setSelectedPeriod(active?.period_id ?? allPeriods[0]?.period_id ?? "");
      } catch (e) {
        setError(e instanceof Error ? e.message : "Gagal memuat periode.");
      }
    }
    loadPeriods();
  }, []);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ studentId });
      if (selectedPeriod) params.set("periodId", selectedPeriod);

      const res = await fetch(`/api/dashboard?${params}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? `HTTP ${res.status}`);
      setDashboard(json);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Terjadi kesalahan.");
      setDashboard(null);
    } finally {
      setLoading(false);
    }
  }, [studentId, selectedPeriod]);

  useEffect(() => {
    if (selectedPeriod) loadDashboard();
  }, [selectedPeriod, loadDashboard]);

  return (
    <div className="flex min-h-screen" style={{ fontFamily: "var(--font-nunito)" }}>

      {/* ── Sidebar ── */}
      <aside className="w-52 bg-white border-r border-gray-100 flex flex-col py-5 px-3 shrink-0">
        {/* Logo */}
        <div className="flex flex-col items-center mb-5">
          <div className="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center text-3xl border-2 border-green-100 mb-1">
            🕌
          </div>
          <span className="text-green-600 font-black text-base">Ngaji Sore</span>
          <span className="text-gray-400 text-[10px] tracking-wide">Belajar • Mengaji • Berkah</span>
        </div>

        {/* Logged-in student chip */}
        <div className="bg-green-50 rounded-2xl px-3 py-2.5 mb-3 border border-green-100">
          <p className="text-green-800 font-black text-xs truncate">{studentName}</p>
          <p className="text-green-500 text-[10px] font-semibold mt-0.5">Santri aktif ✅</p>
        </div>

        {/* Period selector */}
        <div className="mb-4">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide px-1">
            Periode
          </label>
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="w-full mt-1 text-xs font-semibold text-gray-700 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-300 cursor-pointer"
          >
            {periods.map((p) => (
              <option key={p.period_id} value={p.period_id}>
                {p.period_name}
              </option>
            ))}
          </select>
        </div>

        {/* Nav */}
        <nav className="flex flex-col gap-1 flex-1">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.label}
              onClick={() => setActiveNav(item.label)}
              className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeNav === item.label
                  ? "bg-green-500 text-white shadow-md shadow-green-200"
                  : "text-gray-500 hover:bg-gray-50"
              }`}
            >
              <span>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

        {/* Logout + thanks card */}
        <div className="mt-4 space-y-2">
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 text-xs font-bold text-gray-400 hover:text-red-500 hover:bg-red-50 py-2 rounded-xl transition-all border border-gray-100 hover:border-red-100"
          >
            <span>🚪</span> Keluar
          </button>
          <div className="bg-green-50 rounded-2xl p-3 text-center border border-green-100">
            <div className="text-3xl mb-1">👨‍👩‍👧</div>
            <p className="text-green-800 font-black text-xs">Terima kasih</p>
            <p className="text-green-600 text-[10px] leading-snug mt-1">
              atas dukungan Ayah Bunda. Semangat ngaji hari ini!
            </p>
            <span className="text-sm mt-1 block">💚</span>
          </div>
        </div>
      </aside>

      {/* ── Main ── */}
      <main className="flex-1 overflow-auto bg-gray-50 p-6">
        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm font-semibold">
            ⚠️ {error}
          </div>
        )}

        {loading && (
          <div className="flex items-center justify-center h-64">
            <div className="text-center space-y-3">
              <div className="text-4xl animate-spin">⭐</div>
              <p className="text-gray-500 font-semibold text-sm">Memuat laporan...</p>
            </div>
          </div>
        )}

        {!loading && dashboard && (
          <div className="fade-in">
            <Dashboard data={dashboard} onRefresh={loadDashboard} />
          </div>
        )}
      </main>
    </div>
  );
}
